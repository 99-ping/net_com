#!/usr/bin/env python
# coding: utf-8

# In[1]:


from selenium import webdriver
driver = webdriver.Edge('D:\\edge download\\edgedriver_win64\\msedgedriver.exe')
driver.get("https://www.baidu.com/")


# In[2]:


input_btn = web.find_element_by_id('kw')
input_btn.send_keys('python', Keys.ENTER)


# In[3]:


p_input = driver.find_element_by_id('kw')
print(p_input)
print(p_input.location)
print(p_input.size)
print(p_input.send_keys('python'))
print(p_input.text)


# In[5]:


p_input = driver.find_element_by_id('kw')
print(p_input)
print(p_input.location)
print(p_input.size)
print(p_input.send_keys('python'))
print(p_input.text)
p_btn = driver.find_element_by_id('su')
p_btn.click()


# In[7]:


p_input = driver.find_element_by_id('kw')
print(p_input)
print(p_input.location)
print(p_input.size)
print(p_input.send_keys('python'))
print(p_input.text)
p_btn = driver.find_element_by_id('su')
p_btn.click()


# In[8]:


from selenium import webdriver
driver = webdriver.Edge('D:\\edge download\\edgedriver_win64\\msedgedriver.exe')
driver.get("https://www.baidu.com/")


# In[9]:


p_input = driver.find_element_by_id('kw')
print(p_input)
print(p_input.location)
print(p_input.size)
print(p_input.send_keys('python'))
print(p_input.text)
p_btn = driver.find_element_by_id('su')
p_btn.click()


# In[10]:


from selenium import webdriver
driver = webdriver.Edge('D:\\edge download\\edgedriver_win64\\msedgedriver.exe')
driver.get("http://quotes.toscrape.com/js/")


# In[14]:


import time
import csv
from bs4 import BeautifulSoup as bs
from selenium import webdriver
driver = webdriver.Edge(executable_path=r'D:\\edge download\\edgedriver_win64\\msedgedriver.exe')
driver.get('http://quotes.toscrape.com/js/')
#定义csv表头
quote_head=['名言','作者']
#csv文件的路径和名字
quote_path='名人名言.csv'
#存放内容的列表
sayingAndAuthor=[]


def write_csv(csv_head,csv_content,csv_path):
    with open(csv_path, 'w', newline='',encoding='utf-8') as file:
        fileWriter =csv.writer(file)
        fileWriter.writerow(csv_head)
        fileWriter.writerows(csv_content)       
n = 10
for i in range(0, n):
    div_list = driver.find_elements_by_class_name('quote')
    for div in div_list:
        saying = div.find_element_by_class_name('text').text
        author = div.find_element_by_class_name('author').text
        info=[]
        info.append(saying)
        info.append(author)
        sayingAndAuthor.append(info)
        write_csv(quote_head,sayingAndAuthor,quote_path)
    print('成功爬取第' + str(i + 1) + '页')
    if i == n-1:
        break
    driver.find_elements_by_css_selector('[aria-hidden]')[-1].click()
    time.sleep(2)
driver.close()


# In[15]:


from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
from lxml import etree
import csv
all_book_info = []
num=200
head=['书名', '价格', '作者', '出版社']
#csv文件的路径和名字
path='计算机科学与技术.csv'
def write_csv(head,all_book_info,path):
    with open(path, 'w', newline='',encoding='utf-8') as file:
        fileWriter =csv.writer(file)
        fileWriter.writerow(head)
        fileWriter.writerows(all_book_info) 
# 爬取一页
def get_onePage_info(web,num):
    web.execute_script('window.scrollTo(0, document.body.scrollHeight);')
    time.sleep(2)
    page_text = web.page_source
    # with open('3-.html', 'w', encoding='utf-8')as fp:
    #     fp.write(page_text)
    # 进行解析
    tree = etree.HTML(page_text)
    li_list = tree.xpath('//li[contains(@class,"gl-item")]')
    for li in li_list:
        num=num-1
        book_infos = []
        book_name = ''.join(li.xpath('.//div[@class="p-name"]/a/em/text()'))     # 书名
        book_infos.append(book_name)
        price = '￥' + li.xpath('.//div[@class="p-price"]/strong/i/text()')[0]   # 价格
        book_infos.append(price)
        author_span = li.xpath('.//span[@class="p-bi-name"]/a/text()')
        if len(author_span) > 0:  # 作者
            author = author_span[0]
        else:
            author = '无'
        book_infos.append(author)
        store_span = li.xpath('.//span[@class="p-bi-store"]/a[1]/text()')  # 出版社
        if len(store_span) > 0:
            store = store_span[0]
        else:
            store = '无'
        book_infos.append(store)
        all_book_info.append(book_infos)
        if num==0:
            break
    return num

web = webdriver.Edge(executable_path=r'D:\\edge download\\edgedriver_win64\\msedgedriver.exe')
web.get('https://www.jd.com/')
web.maximize_window() # 全屏
web.find_element_by_id('key').send_keys('计算机科学与技术', Keys.ENTER)  # 找到输入框输入，回车
time.sleep(2)

while num!=0:
    num=get_onePage_info(web,num)
    web.find_element_by_class_name('pn-next').click()  # 点击下一页
    time.sleep(2)
write_csv(head,all_book_info,path)
web.close()


# In[ ]:




